## 50.Grup İşletim Sistemleri Proje Ödevi
**Grup Üyeleri:**
- Erim Vurucu
- Kayra Tuluay
- Furkan Aktaş
- Grup listesindeki diğer 2 kişi bize ulaşmadı

**Dizinlerin listesi:**
- shell.c : ana program

**Derleme için:**
- GCC kullanılarak "gcc shell.c" yazılarak derlenebilir.

**Çalıştırma için:**
- "./a.out" yazılarak çalıştırılabilinir.

**Yardımcı kaynaklar:**
- [geeksforgeeks](https://www.geeksforgeeks.org/)
- [stackoverflow](https://stackoverflow.com/)
- [systutorials](https://www.systutorials.com/)

**Geliştirme sırasında karşılaşılan zorluklar:**
- Derleme hatalarının çözümlerini bulmak 
- İstenilen plan doğrultusunda ilerleyememek(hastalık,okul,çalışma...)
- ps komutunun parametrelerinin Kali'de düzgün çalışırken Ubuntu'da düzgün çalışmaması ya da Ubuntu'da düzgün çalışırken Kali'de düzgün çalışmaması(Cozuldu)
